package web4.deelopdracht1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Deelopdracht1Application {

    public static void main(String[] args) {
        SpringApplication.run(Deelopdracht1Application.class, args);
    }

}
