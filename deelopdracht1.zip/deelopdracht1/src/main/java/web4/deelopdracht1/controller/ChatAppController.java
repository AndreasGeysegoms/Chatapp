package web4.deelopdracht1.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import web4.deelopdracht1.domain.Person;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import web4.deelopdracht1.domain.PersonService;
import web4.deelopdracht1.domain.Status;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Controller
public class ChatAppController {

    private PersonService personService = new PersonService();

    @RequestMapping("/")
    public String getIndex() {
        return "index.html";
    }

    @RequestMapping("/chat")
    public String getChat(HttpServletResponse response) throws IOException {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session= attr.getRequest().getSession(true);
        Person user = (Person) session.getAttribute("user");
        ArrayList<Person> friends = (ArrayList<Person>) user.getFriends();
        for (Person friend : friends) {
            String friendJSON = this.toJSON(personService.getPerson(friend.getUserId()));
            response.setContentType("application/json");
            response.getWriter().write(friendJSON);
        }
        //TODO: asynchronous
        return "chat.html";
    }

    public String toJSON (Person person) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(person);
    }

    @PostMapping
    @RequestMapping("/login")
    //TODO: errors showen niet meer
    public String login(@ModelAttribute(name = "email")  String email, @ModelAttribute(name = "password") String password, Model model) {
        List<String> errors = new ArrayList<String>();

        if (email == null || email.isEmpty()) {
            errors.add("No email given");
        }

        if (password == null || password.isEmpty()) {
            errors.add("No password given");
        }

        if (errors.size() == 0) {
            Person person = personService.getAuthenticatedUser(email, password);
            if (person != null) {
                ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
                HttpSession session= attr.getRequest().getSession(true);
                person.setStatus(Status.ONLINE.getString());
                session.setAttribute("user",person);
            } else {
                errors.add("No valid email/password");
            }
        }

        if (errors.size() > 0) {
            model.addAttribute("errors", errors);
        }

        return "redirect:/";
    }

    @PostMapping
    @RequestMapping("/logout")
    public String logout(Model model) {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session= attr.getRequest().getSession(true);
        session.setAttribute("user",null);
        return "redirect:/";
    }

    @PostMapping
    @RequestMapping("/updateStatus")
    public String changeStatus(@ModelAttribute(name = "status") String status ,Model model) {
        if (!status.trim().isEmpty()) {
            ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
            HttpSession session= attr.getRequest().getSession(true);
            Person user = (Person) session.getAttribute("user");
            user.setStatus(status);
            session.setAttribute("user",user);
            //TODO: asynchronous
        }
        else model.addAttribute("errors","Please choose a valid status.");
        return "redirect:/chat";
    }

    @PostMapping
    @RequestMapping("/addFriend")
    public String addFriend(@ModelAttribute (name="email") String email, Model model) {
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session= attr.getRequest().getSession(true);
        Person user = (Person) session.getAttribute("user");
        user = personService.addFriend(user, email);
        session.setAttribute("user",user);
        //TODO: asynchronous
        return "redirect:/chat";
    }
}
