window.onload = getStatus;

var xHRObject = new XMLHttpRequest();

function getStatus () {
    xHRObject.open("GET", "/chat", true);
    xHRObject.onreadystatechange = getData;
    xHRObject.send();
}

function getData () {
    if (xHRObject.status == 200) {
        if (xHRObject.readyState == 4) {
            var serverResponse = JSON.parse(xHRObject.responseText);
            var table = document.getElementById("friends");

            console.log(serverResponse);
            for (i = 0; i < serverResponse.length; i++) {

                var tr = table.childNodes[i];

                var friend = serverResponse[i].friend;
                var status = serverResponse[i].status;

                var tableRow = document.createElement("tr");
                var tableDataName = document.createElement("td");
                var tableDataStatus = document.createElement("td");

                if (tr.childNodes[i].innerHTML === friend) {
                    tableDataName.innerHTML = friend;
                    tableDataStatus.innerHTML = status;

                    tableRow.appendChild(tableDataName);
                    tableRow.appendChild(tableDataStatus);
                    table.removeChild(tr);
                    table.appendChild(tableRow);
                }
                else {
                    tableDataName.innerHTML = friend;
                    tableDataStatus.innerHTML = status;

                    tableRow.appendChild(tableDataName);
                    tableRow.appendChild(tableDataStatus);
                    table.appendChild(tableRow);
                }

            }

            setTimeout(getNewQuote, 2000);
        }
    }
}