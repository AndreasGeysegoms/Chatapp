package web4.deelopdracht1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Deelopdracht1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
